# REST API Lab — Recipe API

**Name:** ___________________________  
**Date:** ___________________________

## Introduction

In this lab you will explore a **REST API** — a way for programs to talk to a server using URLs and HTTP verbs (GET, POST, PUT, PATCH, DELETE).

You will use the **Recipe API** running on your computer. For each exercise:

1. **Predict** — What do you think will happen? (status code, number of results, response shape)
2. **Try** — Send the request in Swagger or Insomnia
3. **Compare** — Was your prediction correct? Explain why or why not.

---

## Part 0 — Setup

1. Open the project in **IntelliJ**.
2. Run **SpringDemoApplication** (green play button).
3. Wait until the console shows `Started SpringDemoApplication`.
4. Open one of these tools:
   - **Swagger (browser):** `http://localhost:8080/swagger-ui/index.html`
   - **Insomnia:** use base URL `http://localhost:8080`
5. Confirm you see **Recipe API** with endpoints under `/api/recipes`.

> **Note:** On first run the app loads 18 sample recipes. If your list looks empty or wrong, stop the app, delete `database-name.db` in the project folder, and restart.

---

## Part 1 — Vocabulary

Fill in from class discussion or by exploring Swagger.

| Term | Meaning | Example from this API |
|------|---------|------------------------|
| **Endpoint** | A URL + HTTP verb the server responds to | `GET /api/recipes` |
| **HTTP verb (method)** | The action you want to perform | GET = read, POST = create, PUT = replace, PATCH = partial update, DELETE = remove |
| **Path parameter** | Part of the URL path; often identifies one specific resource | `/api/recipes/3` → id = 3 |
| **Query parameter** | Optional filter added after `?` in the URL | `/api/recipes?name=soup` |
| **Request body** | JSON data sent with POST, PUT, or PATCH | `{ "name": "...", "ingredients": "...", "instructions": "..." }` |
| **Status code** | A number telling you how the request went | 200 OK, 201 Created, 404 Not Found, 400 Bad Request |

**Mini question:** In `GET /api/recipes/5?name=soup`, which part is the path parameter and which is the query parameter?

**Your answer:**

________________________________________________________________________________

---

## Part 2 — GET: Read Data

GET requests **read** data. They do not change anything on the server.

### Exercise 2A — List all recipes

| | Your answer |
|---|-------------|
| **Request** | `GET /api/recipes` |
| **Predict — status code** | |
| **Predict — how many recipes? (approx.)** | |
| **Predict — response shape (array or single object?)** | |
| **Actual status code** | |
| **Actual count** | |
| **Match?** Yes / No — explain | |

---

### Exercise 2B — Query parameters (filters)

Query parameters **filter** results. This API uses **contains** matching (partial match), not exact match.

For each request, predict how many recipes you will get, then try it in Swagger or Insomnia.

| Request | Predict # of results | Actual # of results | Recipe names you got |
|---------|----------------------|---------------------|----------------------|
| `GET /api/recipes?name=soup` | | | |
| `GET /api/recipes?ingredients=garlic` | | | |
| `GET /api/recipes?ingredients=tomato` | | | |
| `GET /api/recipes?name=pasta&ingredients=garlic` | | | |
| `GET /api/recipes?name=xyznotfound` | | | |

**Reflection:** What is the difference between a query parameter and a path parameter?

**Your answer:**

________________________________________________________________________________

________________________________________________________________________________

---

### Exercise 2C — Path parameter (get one recipe by id)

| Request | Predict status code | Predict what you will see | Actual result |
|---------|---------------------|---------------------------|---------------|
| `GET /api/recipes/1` | | One recipe with id 1 | |
| `GET /api/recipes/999` | | | |
| `GET /api/recipes/abc` | | | |

**Key idea:** Path parameters usually identify **which** resource you want. Query parameters usually **filter** a collection.

---

## Part 3 — POST: Create a New Recipe

POST requests **create** new data. You send a JSON **request body**.

**Endpoint:** `POST /api/recipes`

**Example body (all three fields required):**

```json
{
  "name": "Grilled Cheese",
  "ingredients": "bread, cheddar, butter",
  "instructions": "Butter bread, add cheese, grill until melted."
}
```

### Exercise 3A — Successful create

| | Your answer |
|---|-------------|
| **Predict — status code** | |
| **Predict — will the response include an `id`?** | |
| **Actual status code** | |
| **Actual `id` returned** | |

**Verify:** Send `GET /api/recipes/{your-new-id}`. Does your recipe appear?

Yes / No — what did you see?

________________________________________________________________________________

---

### Exercise 3B — Validation error (400 Bad Request)

Send a POST with this invalid body:

```json
{
  "name": "AB",
  "ingredients": "",
  "instructions": "Test"
}
```

| | Your answer |
|---|-------------|
| **Predict — status code** | |
| **Predict — will you get an error message?** | |
| **Actual status code** | |
| **One error message from the response** | |

**Reflection:** Why does POST usually need a request body, but GET usually does not?

**Your answer:**

________________________________________________________________________________

---

## Part 4 — PUT: Full Replace

PUT **replaces the entire resource**. You must send **all** fields every time, even if you only want to change one.

**Endpoint:** `PUT /api/recipes/{id}`

Use the `id` from your Grilled Cheese recipe in Exercise 3A (or any existing id).

**Example body:**

```json
{
  "name": "Ultimate Grilled Cheese",
  "ingredients": "sourdough, cheddar, gruyere, butter",
  "instructions": "Grill slowly on medium heat until golden and cheese melts."
}
```

| | Your answer |
|---|-------------|
| **Predict — status code if id exists** | |
| **Predict — status code if id is 99999** | |
| **Actual status code (your id)** | |

**Compare PUT vs POST:** In one sentence, when do you use POST vs when do you use PUT?

**Your answer:**

________________________________________________________________________________

---

## Part 5 — PATCH: Partial Update

PATCH **changes only the fields you send**. Other fields stay the same.

**Endpoint:** `PATCH /api/recipes/{id}`

Use the same recipe id from Part 4.

**Example body (only name):**

```json
{
  "name": "Super Grilled Cheese"
}
```

| | Your answer |
|---|-------------|
| **Predict — status code** | |
| **Predict — will `ingredients` and `instructions` change or stay the same?** | |
| **Actual result** | |

---

Now try PATCH with an empty body:

```json
{}
```

| Predict status code | Actual status code | Why did the server respond that way? |
|---------------------|--------------------|--------------------------------------|
| | | |

**Compare PUT vs PATCH:** When would you use PATCH instead of PUT?

**Your answer:**

________________________________________________________________________________

---

## Part 6 — DELETE: Remove a Recipe

DELETE **removes** a resource.

**Endpoint:** `DELETE /api/recipes/{id}`

Use a recipe id you created for testing. Do not delete a recipe you still need for other exercises.

| Request | Predict status code | Predict response body (empty or JSON?) | Actual result |
|---------|---------------------|----------------------------------------|---------------|
| `DELETE /api/recipes/{your-test-id}` | | | |
| `GET /api/recipes/{same-id}` right after delete | | | |
| `DELETE /api/recipes/{same-id}` again | | | |

**Key idea:** Status code **204 No Content** means the request succeeded and there is no response body.

---

## Part 7 — Status Code Summary

Complete this table from your own lab results.

| Code | Meaning | You saw it when… |
|------|---------|------------------|
| 200 | OK | |
| 201 | Created | |
| 204 | No Content | |
| 400 | Bad Request | |
| 404 | Not Found | |

---

## Part 8 — Capstone (Optional)

Write your own API scenario and trade with a partner.

1. Write a scenario (what request to send).
2. Your partner **predicts** the outcome without running it.
3. You run the request and check together.

**Example scenarios:**

- Get all recipes where `ingredients=rice`
- Create a recipe with a 2-letter name
- PATCH recipe 2 to change only the instructions
- DELETE recipe 999

**Your scenario:**

________________________________________________________________________________

________________________________________________________________________________

**Partner's prediction:**

________________________________________________________________________________

**Actual result:**

________________________________________________________________________________

---

## Tool Reference — Swagger

1. Open `http://localhost:8080/swagger-ui/index.html`
2. Expand the recipe controller section.
3. Click an endpoint, then click **Try it out**.
4. Fill in path parameters, query parameters, or request body as needed.
5. Click **Execute**.
6. Read the **Code** (status) and **Response body**.

---

## Tool Reference — Insomnia

| Field | What to enter |
|-------|---------------|
| Method | GET, POST, PUT, PATCH, or DELETE |
| URL | `http://localhost:8080/api/recipes` (add `/id` or `?params` as needed) |
| Query params | Params tab — e.g. `name` = `soup` |
| Request body | Body tab → JSON — for POST, PUT, and PATCH only |

---

## Submission Checklist

- [ ] All predict / actual tables filled in
- [ ] Reflection questions answered
- [ ] Status code summary completed
- [ ] Lab submitted by due date
