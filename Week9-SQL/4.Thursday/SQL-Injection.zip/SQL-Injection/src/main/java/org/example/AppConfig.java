package org.example;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class AppConfig {
    private static final String DEFAULT_JDBC_URL = "jdbc:mysql://localhost:3306/Northwind";
    private static final String DEFAULT_DEMO_MODE = "safe";

    private final String jdbcUrl;
    private final String demoMode;

    private AppConfig(String jdbcUrl, String demoMode) {
        this.jdbcUrl = jdbcUrl;
        this.demoMode = demoMode;
    }

    public static AppConfig load() {
        Properties properties = new Properties();
        try (InputStream in = AppConfig.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (in != null) {
                properties.load(in);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load application.properties", e);
        }

        String jdbcUrl = firstNonBlank(
                System.getProperty("jdbc.url"),
                properties.getProperty("jdbc.url"),
                DEFAULT_JDBC_URL
        );
        String demoMode = firstNonBlank(
                System.getProperty("demo.mode"),
                properties.getProperty("demo.mode"),
                DEFAULT_DEMO_MODE
        ).toLowerCase();

        return new AppConfig(jdbcUrl, demoMode);
    }

    public String jdbcUrl() {
        return jdbcUrl;
    }

    public boolean isSafeMode() {
        return !"unsafe".equals(demoMode);
    }

    public String demoMode() {
        return demoMode;
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value.trim();
            }
        }
        return "";
    }
}
