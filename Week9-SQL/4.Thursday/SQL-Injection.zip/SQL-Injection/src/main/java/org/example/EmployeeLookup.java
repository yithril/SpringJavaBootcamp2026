package org.example;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public final class EmployeeLookup {
    /**
     * Intentionally omits SSN — the app is only meant to show a name lookup.
     * SSN exists in the table (see sql/01-add-ssn.sql) but must not appear in normal results.
     */
    static final String SELECT_BY_EMPLOYEE_ID =
            "SELECT FirstName, LastName FROM Employees WHERE EmployeeID = ";

    static final String SELECT_BY_EMPLOYEE_ID_PARAMETERIZED =
            "SELECT FirstName, LastName FROM Employees WHERE EmployeeID = ?";

    private EmployeeLookup() {
    }

    static String readEmployeeId(Scanner scanner) {
        System.out.println("Enter EmployeeID:");
        return scanner.nextLine().trim();
    }

    static void printResults(ResultSet rs) throws SQLException {
        int count = 0;
        while (rs.next()) {
            count++;
            System.out.printf(
                    "FirstName: %s | LastName: %s%n",
                    rs.getString("FirstName"),
                    rs.getString("LastName")
            );
        }

        if (count == 0) {
            System.out.println("No employee found with that ID.");
        }
    }
}
