package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UnsafeQueryManager {
    public void queryDatabase(String username, String password, String url) {
        try (Scanner scanner = new Scanner(System.in)) {
            String employeeId = EmployeeLookup.readEmployeeId(scanner);
            String query = EmployeeLookup.SELECT_BY_EMPLOYEE_ID + employeeId;

            System.out.println("Executing: " + query);

            try (Connection conn = DriverManager.getConnection(url, username, password);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                EmployeeLookup.printResults(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
