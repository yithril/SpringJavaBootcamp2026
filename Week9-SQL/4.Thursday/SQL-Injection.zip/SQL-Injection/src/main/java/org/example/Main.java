package org.example;

public class Main {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Usage: java -jar ... <db-username> <db-password>");
            System.err.println("Configure jdbc.url and demo.mode in application.properties");
            System.err.println("  or override: -Djdbc.url=... -Ddemo.mode=unsafe");
            System.exit(1);
        }

        AppConfig config = AppConfig.load();
        String username = args[0];
        String password = args[1];

        System.out.println("Employee directory lookup");
        System.out.println("Mode: " + (config.isSafeMode() ? "safe" : "unsafe"));
        System.out.println();

        if (config.isSafeMode()) {
            new SafeQueryManager().queryDatabase(username, password, config.jdbcUrl());
        } else {
            new UnsafeQueryManager().queryDatabase(username, password, config.jdbcUrl());
        }
    }
}
