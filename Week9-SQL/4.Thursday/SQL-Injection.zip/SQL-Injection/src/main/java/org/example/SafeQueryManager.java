package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SafeQueryManager {
    public void queryDatabase(String username, String password, String url) {
        try (Scanner scanner = new Scanner(System.in)) {
            String employeeIdInput = EmployeeLookup.readEmployeeId(scanner);

            try (Connection conn = DriverManager.getConnection(url, username, password);
                 PreparedStatement ps = conn.prepareStatement(EmployeeLookup.SELECT_BY_EMPLOYEE_ID_PARAMETERIZED)) {

                ps.setString(1, employeeIdInput);

                try (ResultSet rs = ps.executeQuery()) {
                    EmployeeLookup.printResults(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
