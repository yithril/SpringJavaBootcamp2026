# SQL Injection Lab (Northwind)

A console app that looks up an employee by ID and prints **first and last name**. Your job is to test whether user input is handled safely.

## Prerequisites

- Java 17+
- Maven
- MySQL 8 with the **Northwind** database (`Employees` table)
- Database credentials from your instructor

Your instructor prepares the database before class. You do **not** need to run scripts in `sql/` unless told otherwise.

## Configure and run

Edit `src/main/resources/application.properties` if your instructor gives you a non-default URL:

```properties
jdbc.url=jdbc:mysql://localhost:3306/Northwind
demo.mode=unsafe
```

Build and run (use credentials provided in class):

```bash
mvn compile
mvn exec:java -Dexec.args="YOUR_DB_USER YOUR_DB_PASSWORD" -Ddemo.mode=unsafe
```

Compare with safe mode:

```bash
mvn exec:java -Dexec.args="YOUR_DB_USER YOUR_DB_PASSWORD" -Ddemo.mode=safe
```

## Suggested lab flow

1. **Normal use** — Enter a valid `EmployeeID` (e.g. `1`). Note what fields the app returns.
2. **Test for injection** — Can you change the query behavior with crafted input? (Hint: the app builds SQL with string concatenation in unsafe mode; watch what SQL gets printed.)
3. **UNION** — The legitimate query returns two columns. Can you append a second `SELECT` that returns the same number of columns?
4. **Discovery** — The UI never mentions extra sensitive fields. If something sensitive exists in the database, can you find **column names** (e.g. via `information_schema`) and then **read values** with a second `UNION SELECT`?
5. **Defense** — Repeat your best attack in `demo.mode=safe`. What changed?

**Why UNION?** The app's query only returns two columns (names). To leak *other* data from the table, you need a second `SELECT` with the same column count — not just `OR 1=1`, which only repeats the columns the app already asked for.

Document each payload you try and what appeared on screen.

## Project layout

| Path | Description |
|------|-------------|
| `src/main/java/org/example/` | Application code |
| `src/main/resources/application.properties` | JDBC URL and `demo.mode` |
| `sql/` | Instructor database setup (not part of the student challenge) |

## Ethics

Use only the training database your instructor provides. Do not run injection experiments against real systems.

**Instructors:** see [TEACHERS_NOTES.md](TEACHERS_NOTES.md) and [docs/teacher-answer-key.txt](docs/teacher-answer-key.txt).
