# Database setup (MySQL + Northwind)

This lab expects the **Northwind** sample database on **MySQL 8** with an `Employees` table.

## Who runs this?

| Role | Action |
|------|--------|
| **Instructor** (usual) | Run `01` and `02` before class; students never need this folder |
| **Student** (optional) | Only if your instructor assigns DB setup — still do not announce what sensitive column was added |

Script `01-add-ssn.sql` adds a **fake `SSN` column** so UNION-based exfiltration has something to find. That fact is for instructors ([TEACHERS_NOTES.md](../TEACHERS_NOTES.md)), not for the student handout.

## Before you run scripts

1. Install MySQL and import a Northwind database named `Northwind` (or adjust `jdbc.url` in `application.properties`).
2. Connect with a client (MySQL Workbench, `mysql` CLI, etc.) and select the database:

```sql
USE Northwind;
```

## Setup (required once per database)

Run in order:

| Script | Purpose |
|--------|---------|
| `01-add-ssn.sql` | Adds `SSN` column and fills fake values |
| `02-verify-setup.sql` | Confirms SSN data is present |

Example (CLI):

```bash
mysql -u root -p Northwind < sql/01-add-ssn.sql
mysql -u root -p Northwind < sql/02-verify-setup.sql
```

## Teardown (optional)

`99-rollback-ssn.sql` removes the `SSN` column if you want to restore the original schema.

## Troubleshooting

| Error | Fix |
|-------|-----|
| `Table 'Northwind.Employees' doesn't exist` | Wrong database or Northwind not imported |
| `Unknown database 'Northwind'` | Create/import Northwind or change `jdbc.url` |
| `Duplicate column name 'SSN'` | Re-run `01-add-ssn.sql` is safe; if it still fails, run `99-rollback-ssn.sql` then `01` again |

**Note:** `01-add-ssn.sql` uses MySQL-specific syntax (`INFORMATION_SCHEMA`, `PREPARE`). For PostgreSQL Northwind, scripts would need to be adapted and `jdbc.url` should use the PostgreSQL driver.
