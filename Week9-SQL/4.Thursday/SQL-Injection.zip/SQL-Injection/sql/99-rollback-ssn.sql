-- Removes the SSN column added for this lab. Safe to re-run if column is already gone.

SET @ssn_exists = (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'Employees'
      AND COLUMN_NAME = 'SSN'
);

SET @ddl = IF(
    @ssn_exists = 1,
    'ALTER TABLE Employees DROP COLUMN SSN',
    'SELECT ''Column SSN does not exist; nothing to drop.'' AS message'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
