-- Run after 01-add-ssn.sql. Expect non-null SSN values in ###-##-#### format.

SELECT EmployeeID, FirstName, LastName, SSN
FROM Employees
ORDER BY EmployeeID
LIMIT 5;

SELECT COUNT(*) AS employees_with_ssn
FROM Employees
WHERE SSN IS NOT NULL AND SSN <> '';
