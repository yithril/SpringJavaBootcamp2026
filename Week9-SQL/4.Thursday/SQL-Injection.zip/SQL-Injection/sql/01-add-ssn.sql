-- Adds a fake SSN column to Northwind Employees for the SQL injection lab.
-- Safe to re-run: skips ALTER if SSN already exists; only fills NULL/empty SSN values.

SET @ssn_exists = (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'Employees'
      AND COLUMN_NAME = 'SSN'
);

SET @ddl = IF(
    @ssn_exists = 0,
    'ALTER TABLE Employees ADD COLUMN SSN VARCHAR(11)',
    'SELECT ''Column SSN already exists; skipping ALTER.'' AS message'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET SQL_SAFE_UPDATES = 0;

UPDATE Employees
SET SSN = CONCAT(
    LPAD(FLOOR(RAND() * 900) + 100, 3, '0'), '-',
    LPAD(FLOOR(RAND() * 90) + 10, 2, '0'), '-',
    LPAD(FLOOR(RAND() * 9000) + 1000, 4, '0')
)
WHERE SSN IS NULL OR SSN = '';

SET SQL_SAFE_UPDATES = 1;
