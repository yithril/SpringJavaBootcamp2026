# Teacher's Notes — Password Hashing Demo

## Overview

**Time:** 20–30 minutes  
**Audience:** Intro cybersecurity, networking, or programming students  
**Goal:** Students can explain what a hash and a salt are, and why identical hashes enable precomputed attacks.

This demo is intentionally simplified. Say that out loud so students do not think SHA-256 alone is how websites should store passwords today.

---

## Learning objectives

By the end, students should be able to:

1. Describe hashing as a one-way fingerprint (not encryption).
2. Explain that the same password without a salt always produces the same stored value.
3. Explain that a random per-user salt makes precomputed rainbow tables impractical for a stolen database.
4. Recognize that hashing does **not** protect weak passwords — attackers can still guess and check.

---

## Before class

1. Clone or copy the project; confirm `mvn compile exec:java` works (see [README.md](README.md)).
2. Skim `PasswordHasher.java` if students will read source code.
3. Decide whether students run the program themselves or you demo from the projector.

---

## Lesson script

### 1. Set the scene (2 min)

“We store passwords in databases. We should **never** store plain text. This program shows what sites often do instead — and where that still fails.”

Clarify vocabulary:

- **Hash:** one-way function; you cannot “decrypt” it, but you can **guess** a password and hash it to see if it matches.
- **Salt:** random data mixed in before hashing so two users with the same password get different stored values.

### 2. Act 1 — Hashing without salt (5 min)

**Menu option 1.** Enter: `password`

Point out:

- The program hashes the same input twice and prints the same hex both times.
- If a database leaks, every user who used `password` has the **same** stored value.

Ask: *“If you saw this hash in a leak, how could you find the original password?”*  
(Guide toward: try common passwords, hash them, compare.)

### 3. Act 2 — Rainbow table / lookup (5 min)

**Menu option 3** with `password`, then try a password **not** in the table (e.g. `class2026`).

Optional: **Menu option 4** to show the full mini table on screen.

Talking points:

- Attackers build tables of `(password → hash)` for common passwords.
- Hashing did not make `password` secret — it made it a **matching game**.
- This is why “password” and “123456” are still dangerous even if the site “hashes passwords.”

### 4. Act 3 — Salting (5 min)

**Menu option 2.** Enter: `password` again.

Point out:

- Run 1 and Run 2 show different salt and different combined output.
- A stolen table of precomputed hashes for `password` no longer unlocks every user at once — each salt requires separate work.

**Important nuance for stronger students:**  
In this demo, a new salt is generated each run and printed with the hash. In production, the site generates the salt **once when the user registers**, stores it next to the hash, and reuses it when they log in. The demo still illustrates *why* salts exist.

### 5. Act 4 — What real systems do (3 min)

Briefly mention:

- Production systems use **slow** password hashes (bcrypt, Argon2, scrypt), not fast SHA-256.
- Salts are stored in the database (not secret) — they defeat rainbow tables, not offline guessing entirely.
- Strong, unique passwords and MFA still matter.

### 6. Wrap-up discussion (5 min)

Suggested questions:

1. What is the difference between hashing and encryption?
2. Why does salting not help if everyone picks `password`?  
   (Each hash is different, but attackers can still guess `password` and hash with each victim’s salt.)
3. If the hash database leaks, what can an attacker do offline?

---

## Common student misconceptions

| Misconception | Correction |
|---------------|------------|
| “Hashed = safe / encrypted” | Hashed is not reversible like encryption, but **guessable**. |
| “They can’t get my password back” | They can try billions of guesses offline. |
| “Salt is secret” | Salt is usually stored openly; it prevents **shared** precomputation. |
| “SHA-256 is what banks use for passwords” | Banks may use SHA-256 for other things; password storage needs slow, specialized algorithms. |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Program won’t start | Need Java 17+; run `mvn compile exec:java` from project root |
| “Invalid choice” | Enter `1`–`5` only |
| Option 3 never finds password | Table has ~180 common passwords from breach reports; use option 4 or edit `src/main/resources/common-passwords.txt` |
| Students want “real hacking” | Explain this simulates **offline hash cracking**, not live login attacks |

---

## Source files (for code walk)

| File | Role |
|------|------|
| `Main.java` | Menu and classroom scenarios |
| `PasswordHasher.java` | SHA-256 with and without salt |
| `common-passwords.txt` | Wordlist loaded at startup (editable) |
| `CommonPasswordLookup.java` | Loads the wordlist and precomputes unsalted hashes |

---

## Extensions

1. **Homework:** Add three passwords to `src/main/resources/common-passwords.txt` and re-run option 4.
2. **Research:** Compare bcrypt vs SHA-256 speed (why “slow” matters).
3. **Ethics:** Only test systems you own or have permission to test; relate to credential stuffing and breach news.

---

## Assessment ideas

- Short answer: “Why is salting necessary if we already hash passwords?”
- Scenario: “A site stores `SHA-256(password)` with no salt. The DB leaks. Describe two things an attacker can do.”
