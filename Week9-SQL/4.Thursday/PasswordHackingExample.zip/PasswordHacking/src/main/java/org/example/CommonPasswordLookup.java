package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Precomputed "rainbow table" of common passwords (unsalted SHA-256 only).
 * Passwords are loaded from {@code common-passwords.txt} on the classpath.
 */
public final class CommonPasswordLookup {

    private static final String RESOURCE = "common-passwords.txt";

    private static final Map<String, String> PASSWORD_TO_HASH = buildTable();

    private CommonPasswordLookup() {
    }

    private static Map<String, String> buildTable() {
        Map<String, String> table = new LinkedHashMap<>();
        try (InputStream in = CommonPasswordLookup.class.getClassLoader().getResourceAsStream(RESOURCE)) {
            if (in == null) {
                throw new IllegalStateException("Missing resource: " + RESOURCE);
            }
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) {
                        continue;
                    }
                    table.putIfAbsent(line, PasswordHasher.hashWithoutSalt(line));
                }
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to load " + RESOURCE, e);
        }
        if (table.isEmpty()) {
            throw new IllegalStateException("No passwords loaded from " + RESOURCE);
        }
        return Map.copyOf(table);
    }

    public static int size() {
        return PASSWORD_TO_HASH.size();
    }

    public static Optional<String> findHash(String password) {
        return Optional.ofNullable(PASSWORD_TO_HASH.get(password));
    }

    public static Map<String, String> table() {
        return PASSWORD_TO_HASH;
    }
}
