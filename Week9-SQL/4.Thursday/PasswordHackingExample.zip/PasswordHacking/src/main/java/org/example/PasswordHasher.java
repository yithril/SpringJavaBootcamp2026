package org.example;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Educational SHA-256 hashing demos. Not suitable for production password storage.
 */
public final class PasswordHasher {

    private static final int SALT_BYTES = 16;

    private PasswordHasher() {
    }

    public static String hashWithoutSalt(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(password.getBytes());
            return bytesToHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    /**
     * Returns salt (hex) + hash (hex). A new random salt is generated on every call.
     */
    public static SaltedHashResult hashWithSalt(String password) {
        try {
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[SALT_BYTES];
            random.nextBytes(salt);

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            md.update(password.getBytes());
            byte[] hash = md.digest();

            return new SaltedHashResult(bytesToHex(salt), bytesToHex(hash));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
        }
        return sb.toString();
    }

    public record SaltedHashResult(String saltHex, String hashHex) {
        public String combinedHex() {
            return saltHex + hashHex;
        }
    }
}
