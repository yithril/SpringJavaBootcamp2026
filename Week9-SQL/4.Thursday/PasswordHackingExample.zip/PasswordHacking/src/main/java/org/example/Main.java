package org.example;

import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean running = true;
            while (running) {
                printMenu();
                String choice = scanner.nextLine().trim();
                System.out.println();

                switch (choice) {
                    case "1" -> demoHashWithoutSalt(scanner);
                    case "2" -> demoHashWithSalt(scanner);
                    case "3" -> demoRainbowTable(scanner);
                    case "4" -> showRainbowTable();
                    case "5", "q", "Q" -> running = false;
                    default -> System.out.println("Invalid choice. Enter 1–5.");
                }
                System.out.println();
            }
            System.out.println("Goodbye.");
        }
    }

    private static void printMenu() {
        System.out.println("=== Password Hashing Demo ===");
        System.out.println("1. Hash without salt (same password → same hash)");
        System.out.println("2. Hash with salt (same password → different hash each time)");
        System.out.println("3. Check password against common-password table");
        System.out.println("4. Show the built-in common-password table");
        System.out.println("5. Quit");
        System.out.print("Choose an option: ");
    }

    private static void demoHashWithoutSalt(Scanner scanner) {
        String password = promptPassword(scanner);
        String hash1 = PasswordHasher.hashWithoutSalt(password);
        String hash2 = PasswordHasher.hashWithoutSalt(password);

        System.out.println();
        System.out.println("Password: " + password);
        System.out.println("Hash (run 1): " + hash1);
        System.out.println("Hash (run 2): " + hash2);
        System.out.println();
        if (hash1.equals(hash2)) {
            System.out.println("→ Both hashes match. Without a salt, the same password always");
            System.out.println("  produces the same stored value — attackers can precompute tables.");
        }
    }

    private static void demoHashWithSalt(Scanner scanner) {
        String password = promptPassword(scanner);
        PasswordHasher.SaltedHashResult run1 = PasswordHasher.hashWithSalt(password);
        PasswordHasher.SaltedHashResult run2 = PasswordHasher.hashWithSalt(password);

        System.out.println();
        System.out.println("Password: " + password);
        System.out.println();
        printSaltedRun("Run 1", run1);
        System.out.println();
        printSaltedRun("Run 2", run2);
        System.out.println();
        if (!run1.combinedHex().equals(run2.combinedHex())) {
            System.out.println("→ The stored values differ. A random salt breaks precomputed");
            System.out.println("  rainbow tables (each user needs their own guess work).");
            System.out.println("  In production, the salt is saved with the hash and reused at login.");
        }
    }

    private static void printSaltedRun(String label, PasswordHasher.SaltedHashResult result) {
        System.out.println(label + ":");
        System.out.println("  Salt: " + result.saltHex());
        System.out.println("  Hash: " + result.hashHex());
        System.out.println("  Combined (salt + hash): " + result.combinedHex());
    }

    private static void demoRainbowTable(Scanner scanner) {
        String password = promptPassword(scanner);
        var knownHash = CommonPasswordLookup.findHash(password);

        System.out.println();
        if (knownHash.isPresent()) {
            System.out.println("FOUND in the common-password table.");
            System.out.println("Password: " + password);
            System.out.println("Stored hash (unsalted SHA-256): " + knownHash.get());
            System.out.println();
            System.out.println("→ Hashing did not hide a weak password. Attackers compare leaked");
            System.out.println("  hashes to tables like this — salting stops one table for all users,");
            System.out.println("  but strong passwords still matter.");
        } else {
            System.out.println("NOT in this demo's table (" + CommonPasswordLookup.size()
                    + " common passwords from real breach rankings).");
            System.out.println("A real attacker uses much larger wordlists and brute force.");
        }
    }

    private static void showRainbowTable() {
        Map<String, String> table = CommonPasswordLookup.table();
        System.out.println("Common passwords from breach reports (" + table.size() + " entries):");
        System.out.println("(Source: src/main/resources/common-passwords.txt)");
        System.out.println();
        for (Map.Entry<String, String> entry : table.entrySet()) {
            System.out.printf("  %-16s → %s%n", entry.getKey(), entry.getValue());
        }
    }

    private static String promptPassword(Scanner scanner) {
        System.out.print("Enter a password to demo: ");
        return scanner.nextLine();
    }
}
