# Password Hashing Demo

A small classroom program that demonstrates **hashing**, **salting**, and why **hashing alone does not make weak passwords safe**.

Students enter passwords and see how stored values change (or stay the same) under different schemes.

## Requirements

- Java 17 or newer
- [Apache Maven](https://maven.apache.org/) (or an IDE that opens Maven projects)

## How to run

From the project folder:

```bash
mvn compile exec:java
```

In IntelliJ or Eclipse: open the project, run `org.example.Main`.

## Menu options

| Option | What it shows |
|--------|----------------|
| **1. Hash without salt** | Same password hashed twice → identical output |
| **2. Hash with salt** | Same password hashed twice → different output (new salt each time) |
| **3. Check common-password table** | Simulates matching a leaked hash to a precomputed “rainbow table” |
| **4. Show table** | Lists common passwords from `common-passwords.txt` and their unsalted hashes |
| **5. Quit** | Exit |

## Suggested classroom flow

1. Run option **1** with `password` — note the hash is always the same.
2. Run option **3** with `password` — show it appears in the lookup table.
3. Run option **2** with `password` twice in one go — note different stored values.
4. Discuss: hashing is one-way, but guessing and precomputation still work.

The wordlist lives in `src/main/resources/common-passwords.txt` (~180 entries from public breach rankings). Teachers can add or remove lines without changing Java code.

Full lesson script, talking points, and discussion questions: **[TEACHERS_NOTES.md](TEACHERS_NOTES.md)**.

## Important

This project is for **teaching only**. Real applications should use dedicated password APIs (e.g. bcrypt, Argon2, scrypt) with per-user salts stored in the database — not raw SHA-256 as shown here.
